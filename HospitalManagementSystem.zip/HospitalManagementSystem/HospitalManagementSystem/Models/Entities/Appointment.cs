﻿using System.ComponentModel.DataAnnotations;

namespace HospitalManagementSystem.Models.Entities
{
    public class AppointmentClass
    {
        [Key]
        public int AppointmentID { get; set; }
        public int PatientID { get; set; }  // Foreign key to Patient
        public int DoctorID { get; set; }  // Foreign key to Doctor
        public DateTime AppointmentDate { get; set; }
        public string AppointmentStatus { get; set; }  // e.g., scheduled, completed, canceled

        // Navigation properties
        public PatientClass Patient { get; set; }  // Navigation to the Patient entity
        public DoctorClass Doctor { get; set; }  // Navigation to the Doctor entity
    }
}
