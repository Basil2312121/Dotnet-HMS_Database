﻿using System.ComponentModel.DataAnnotations;

namespace HospitalManagementSystem.Models.Entities
{
    public class DoctorClass
    {
        [Key]  // Mark DoctorID as the primary key
        public int DoctorID { get; set; }

        public string DoctorName { get; set; }
        public string Specialty { get; set; }
        public string ContactInfo { get; set; }
        public DateTime? HireDate { get; set; }

        // Navigation property: A Doctor can have multiple appointments
        public ICollection<AppointmentClass> Appointments { get; set; }
    }
}
