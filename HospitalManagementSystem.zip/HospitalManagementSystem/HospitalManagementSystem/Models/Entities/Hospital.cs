﻿using System.ComponentModel.DataAnnotations;

namespace HospitalManagementSystem.Models.Entities
{
    public class HospitalClass
    {
        [Key]  // Mark HospitalID as the primary key
        public int HospitalID { get; set; }

        public string HospitalName { get; set; }
        public string Address { get; set; }
        public string ContactNumber { get; set; }

        // Add any relationships here if necessary
    }
}
