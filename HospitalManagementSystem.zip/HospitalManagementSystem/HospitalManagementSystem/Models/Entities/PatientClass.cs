﻿using System.ComponentModel.DataAnnotations;

namespace HospitalManagementSystem.Models.Entities
{
    public class PatientClass
    {
        [Key]  // Mark PatientID as the primary key
        public int PatientID { get; set; }

        public string PatientName { get; set; }
        public int PatientAge { get; set; }
        public string PatientType { get; set; }
        public DateTime? PatientDate { get; set; }

        // Navigation property: A Patient can have multiple appointments
        public ICollection<AppointmentClass> Appointments { get; set; }
    }
}
