﻿using Microsoft.EntityFrameworkCore;
using HospitalManagementSystem.Models.Entities;

namespace HospitalManagementSystem.Models
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {
        }

        public DbSet<PatientClass> Patients { get; set; }
        public DbSet<DoctorClass> Doctors { get; set; }
        public DbSet<AppointmentClass> Appointments { get; set; }
        public DbSet<HospitalClass> Hospitals { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Define the primary key for HospitalClass explicitly (optional if convention is followed)
            modelBuilder.Entity<HospitalClass>()
                .HasKey(h => h.HospitalID);  // Set HospitalID as the primary key

            // Define other relationships (if any) here

            modelBuilder.Entity<AppointmentClass>()
                .HasOne(a => a.Patient)
                .WithMany(p => p.Appointments)
                .HasForeignKey(a => a.PatientID);

            modelBuilder.Entity<AppointmentClass>()
                .HasOne(a => a.Doctor)
                .WithMany(d => d.Appointments)
                .HasForeignKey(a => a.DoctorID);
        }
    }
}
